﻿using ImagesMVCCRUD.Models;
using Microsoft.EntityFrameworkCore;

namespace ImagesMVCCRUD.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        public DbSet<Product> ProductTbl { get; set; }
    }
}
