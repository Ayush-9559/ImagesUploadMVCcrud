﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ImagesMVCCRUD.Models
{
    public class Product
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string PName { get; set; }
        [Required]
        public string PDescription { get; set; }
        [Required]
        public string Category { get; set; }
        [Required]
        public decimal Price { get; set; }
        public string FilePath { get; set; }
        [NotMapped]
        public IFormFile Image { get; set; }

        public DateTime CreatedAt { get; set; }
    }
}
