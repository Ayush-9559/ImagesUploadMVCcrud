﻿using ImagesMVCCRUD.Data;
using ImagesMVCCRUD.Models;
using Microsoft.AspNetCore.Mvc;

namespace ImagesMVCCRUD.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext db;
        private readonly IWebHostEnvironment env;
        public ProductController(ApplicationDbContext db, IWebHostEnvironment env)
        {
            this.db = db;
            this.env = env;
        }


        public IActionResult Index()
        {
            var listproducts = db.ProductTbl.ToList();
            return View(listproducts);
        }


        private string FileUpload(Product model)
        {
            string uniqueName = "";
            if(model.Image != null)
            {
                string uploadfolder = Path.Combine(env.WebRootPath + "/productimages/");
                uniqueName = Guid.NewGuid().ToString() + "_" + model.Image.FileName;
                 string filePath = Path.Combine(uploadfolder, uniqueName);
                using (var filestream = new FileStream(filePath, FileMode.Create))
                {
                    model.Image.CopyTo(filestream);
                }
            }
            return uniqueName;
        }

        [HttpGet]
        public IActionResult AddProduct()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddProduct(Product p)
        {
            try
            {
                if(!ModelState.IsValid)
                {
                    string uniqueName = FileUpload(p);
                    var addproduct = new Product()
                    {
                        PName = p.PName,
                        PDescription = p.PDescription,
                        Category = p.Category,
                        Price = p.Price,
                        FilePath = uniqueName,
                        CreatedAt = DateTime.Now,
                    };
                    await db.ProductTbl.AddAsync(addproduct);
                    await db.SaveChangesAsync();
                    TempData["Message"] = "Product Added Succesfully !!!";
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);
            }
            return View();
        }



        [HttpGet]
        public async Task<IActionResult> EditProduct(int id)
        {
            var product = await db.ProductTbl.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> EditProduct(Product model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var product = await db.ProductTbl.FindAsync(model.Id);
                    if (product == null)
                    {
                        return NotFound();
                    }

                    product.PName = model.PName;
                    product.PDescription = model.PDescription;
                    product.Category = model.Category;
                    product.Price = model.Price;

                    // Handle image upload if a new image is provided
                    if (model.Image != null)
                    {
                        product.FilePath = FileUpload(model);
                    }

                    product.CreatedAt = DateTime.Now; // Assuming you have this property
                    await db.SaveChangesAsync();
                    TempData["UpdateMessage"] = "Product Updated Successfully !!!";
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);
            }
            return View(model);
        }

        
        public async Task<IActionResult> ProductDetails(int id)
        {
            var readDetails = db.ProductTbl.Where(l => l.Id == id).SingleOrDefault();
            if (readDetails == null)
            {
                return NotFound();
            }
            return View(readDetails);
        }


        //[HttpGet]
        //public async Task<IActionResult> DeleteProduct(int id)
        //{
        //    var product = await db.ProductTbl.FindAsync(id);
        //    if (product == null)
        //    {
        //        return NotFound();
        //    }
        //    return View(product);
        //}

        //[HttpPost, ActionName("DeleteProduct")]
        public async Task<IActionResult> DeleteProduct(Product p)
        {
            var product = await db.ProductTbl.FindAsync(p.Id);
            if (product == null)
            {
                return NotFound();
            }

            // Delete the image file if it exists
            if (!string.IsNullOrEmpty(product.FilePath))
            {
                var imagePath = Path.Combine(env.WebRootPath, "productimages", product.FilePath);
                if (System.IO.File.Exists(imagePath))
                {
                    System.IO.File.Delete(imagePath);
                }
            }

            db.ProductTbl.Remove(product);
            await db.SaveChangesAsync();
            TempData["Message"] = "Product Deleted Successfully !!!";
            return RedirectToAction("Index");
        }


    }
}
